﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows;
using System.Security.RightsManagement;
using static System.Net.Mime.MediaTypeNames;
using System.Linq.Expressions;
using System.Configuration;
using System.Text;

namespace Dashboard_Admin
{
    public partial class MainWindow : Window
    {

        private readonly string connectionString;

        public MainWindow()
        {


            InitializeComponent();
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["MySQLConnectionString"];
            if (settings != null)
            {
                connectionString = settings.ConnectionString;
            }
            else
            {
                MessageBox.Show("bdd non co.");
            }
        }

        /* public void BtnConnect_Click(object sender, RoutedEventArgs e)
         {
             string username = txtUsername.Text;
             string password = txtPassword.Password;
             if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
             {
                 MessageBox.Show("Veuillez entrer un nom d'utilisateur et un mot de passe.");
                 return;
             }
             try {

                 using (MySqlConnection connection = new MySqlConnection(connectionString))
                 {
                     connection.Open();
                     string query = "SELECT COUNT(*) FROM users WHERE username = @Username AND password = @Password";
                     MySqlCommand command = new MySqlCommand(query, connection);
                     command.Parameters.AddWithValue("@Username", username);
                     command.Parameters.AddWithValue("@Password", password);
                     int count = Convert.ToInt32(command.ExecuteScalar());

                     if (count > 0)
                     {
                         MessageBox.Show("Connexion réussie !");
                         //redirection vers la page d'accueil
                         HomePage hommePage = new HomePage();
                         hommePage.Show();
                         Close();
                     }

                     else
                     {
                         MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.");

                     }

                 }
                 }catch (Exception ex)
             {
                 MessageBox.Show("Erreur lors de la connexion :" + ex.Message);
             }
         } */
        /*public void BtnConnect_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Veuillez entrer un nom d'utilisateur et un mot de passe.");
                return;
            }

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM users WHERE username = @Username AND password = @Password";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    if (count > 0)
                    {
                        MessageBox.Show("Connexion réussie !");

                        // Requête pour récupérer les utilisateurs avec une différence de date entre 2 et 3 jours
                        string queryUtilisateurs = "SELECT Utilisateur FROM conges WHERE DATEDIFF(DateDeFin, DateDeJour) BETWEEN 2 AND 3";
                        MySqlCommand cmdUtilisateurs = new MySqlCommand(queryUtilisateurs, connection);
                        using (MySqlDataReader reader = cmdUtilisateurs.ExecuteReader())
                        {
                            StringBuilder message = new StringBuilder();
                            message.Append("Utilisateurs concernés par les congés : \n");

                            while (reader.Read())
                            {
                                string utilisateur = reader.GetString("Utilisateur");
                                message.Append(utilisateur);
                                message.Append("\n");
                            }

                            MessageBox.Show(message.ToString());
                        }

                        // Redirection vers la page d'accueil
                        HomePage homePage = new HomePage();
                        homePage.Show();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la connexion :" + ex.Message);
            }
        } */

        public void BtnConnect_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Veuillez entrer un nom d'utilisateur et un mot de passe.");
                return;
            }

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM users WHERE username = @Username AND password = @Password";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    if (count > 0)
                    {
                        MessageBox.Show("Connexion réussie !");

                        // Les utilisateurs avec la date de fin de congé dans 2 ou 3 jours par rapport à la date de jour 

                        string queryUtilisateur = "SELECT Utilisateur FROM conges WHERE DATEDIFF(DateDeFin, CURRENT_DATE()) BETWEEN 2 AND 3";
                        //"SELECT Utilisateur, DateDeJour FROM conges WHERE DateDeFin - DateDeJour BETWEEN 2 AND 3";
                        MySqlCommand cmdUtilisateurs = new MySqlCommand(queryUtilisateur, connection);
                        using (MySqlDataReader reader = cmdUtilisateurs.ExecuteReader())
                        {
                            StringBuilder message = new StringBuilder();
                            message.Append("Voici les utilisateurs concernés par les congés dans 2 ou 3 jours : \n");

                            while (reader.Read())
                            {
                                string utilisateur = reader.GetString("Utilisateur");
                             //   DateTime dateDeJour = reader.GetDateTime("DateDeJour");
                               // DateTime dateDeFin = reader.GetDateTime("DateDeFin");
                                message.Append(utilisateur);
                              //  message.Append(" DateDeFin - DateDeJour : ");
                             //   message.Append(dateDeJour.ToString("yyyy/MM/dd")); 
                                message.Append("\n");
                            }

                            if (message.Length > 0)
                            {
                                MessageBox.Show(message.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Aucun utilisateur n'a de congé dans les deux ou les trois prochains jours.");
                            }
                        }
                        using (MySqlDataReader reader = cmdUtilisateurs.ExecuteReader())
                        {
                            StringBuilder message = new StringBuilder();
                            message.Append("Congés arrivée dans les deux jours : \n");

                            while (reader.Read())
                            {
                                string utilisateur = reader.GetString("Utilisateur");
                                DateTime dateDeJour = reader.GetDateTime("DateDeJour");
                                DateTime dateDeFin = reader.GetDateTime("DateDeFin");

                                // 
                                string dateDeDebut = dateDeJour.ToString("yyyy-MM-dd HH:mm:ss");
                               // string dateDeFinLisible = dateDeFin.ToString("yyyy-MM-dd HH:mm:ss");

                                // message qui apparait pourquoi il apparait pas ? 
                                message.Append(utilisateur);
                                message.Append(" - Date de début : ");
                                message.Append(dateDeDebut);
                              //  message.Append(" - Date de fin : ");
                              //  message.Append(dateDeFinLisible);
                                message.Append(" - Date de jour : ");
                                message.Append(dateDeJour.ToString("yyyy-MM-dd")); 
                                message.Append("\n");
                            }

                            if (message.Length > 0)
                            {
                                MessageBox.Show(message.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Aucun utilisateur n'a de congé dans les deux ou les trois prochains jours.");
                            }
                        }


                        // Redirection vers la page d'accueil
                        HomePage homePage = new HomePage();
                        homePage.Show();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la connexion :" + ex.Message);
            }
        }


    }
}

              